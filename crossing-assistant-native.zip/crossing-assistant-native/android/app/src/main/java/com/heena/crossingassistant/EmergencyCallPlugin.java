package com.heena.crossingassistant;

import android.Manifest;
import android.content.Intent;
import android.net.Uri;

import com.getcapacitor.PermissionState;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.annotation.Permission;
import com.getcapacitor.annotation.PermissionCallback;

/**
 * Places a phone call to the saved emergency contact.
 * The web layer only calls this AFTER the user has given consent in Settings and the on-screen
 * countdown has finished without being cancelled. Android asks for the CALL_PHONE permission
 * the first time. Not compiled or tested on a device yet.
 */
@CapacitorPlugin(
    name = "EmergencyCall",
    permissions = { @Permission(strings = { Manifest.permission.CALL_PHONE }, alias = "call") }
)
public class EmergencyCallPlugin extends Plugin {

    @PluginMethod
    public void call(PluginCall call) {
        String number = call.getString("number");
        if (number == null || !number.matches("[+0-9]{3,20}")) {
            call.reject("Invalid phone number");
            return;
        }
        if (getPermissionState("call") != PermissionState.GRANTED) {
            requestPermissionForAlias("call", call, "callPermissionResult");
            return;
        }
        placeCall(call, number);
    }

    @PermissionCallback
    private void callPermissionResult(PluginCall call) {
        if (getPermissionState("call") == PermissionState.GRANTED) {
            placeCall(call, call.getString("number"));
        } else {
            call.reject("Call permission denied");
        }
    }

    private void placeCall(PluginCall call, String number) {
        try {
            Intent intent = new Intent(Intent.ACTION_CALL, Uri.parse("tel:" + number));
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(intent);
            call.resolve();
        } catch (Exception e) {
            call.reject("Could not start the call: " + e.getMessage());
        }
    }
}

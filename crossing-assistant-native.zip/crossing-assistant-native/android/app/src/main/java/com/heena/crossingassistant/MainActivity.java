package com.heena.crossingassistant;

import android.os.Bundle;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(EmergencyCallPlugin.class);   // custom native plugin: user-confirmed emergency call
        super.onCreate(savedInstanceState);
    }
}
